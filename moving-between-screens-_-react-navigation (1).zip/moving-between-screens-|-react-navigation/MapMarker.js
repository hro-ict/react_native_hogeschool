import React from 'react';
import { View, Button, Text } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import openMap from 'react-native-open-maps';
import { Avatar, Button as BTN, Card, Text as TXT } from 'react-native-paper';

const App = ({ route }) => {
   const { lat, long, desc} = route.params;
  const openLocationInMaps = () => {
    const latitude = 37.7749; // Vervang dit met de gewenste breedtegraad
    const longitude = -122.4194; // Vervang dit met de gewenste lengtegraad

    openMap({ latitude, longitude });
  };

  return (
    <View style={{ flex: 1 }}>
    <Text style={{fontSize:30, textAlign:"center", marginTop:20}}>{desc}</Text>
      <MapView
        style={{ flex: 1, marginTop:50 }}
        initialRegion={{
          latitude: 51.85773920010014,
          longitude: 4.295741841626778,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        <Marker
          coordinate={{ latitude: lat, longitude: long }}
          title="Marker 1"
          description="This is marker 1"
        />
    
      </MapView>

      <Button title="" onPress={openLocationInMaps} />
      
    </View>
  );
};

export default App;
