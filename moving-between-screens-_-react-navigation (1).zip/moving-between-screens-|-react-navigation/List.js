import * as React from 'react';
import { Avatar, Button, Card, Text } from 'react-native-paper';
import {View, Text as txt} from "react-native";


const LeftContent = props => <Avatar.Icon {...props} icon="map" />
const locationData2 = [
  // {latitude: current_lat, longitude: current_long, desc: "current", color:"green"},
  {latitude: 51.910387777297345, 
  longitude: 4.4639805215644, 
  desc: "Academieplein",
  color: "blue",
  adress: "G.J. de Jonghweg 4-6"
},
  {latitude: 51.90668123869861, 
  longitude: 4.459002341955153, 
  desc:"Peter de Hoochweg",
  color:"green",
  adress: "Peter de Hoochweh 129"
},
  {latitude: 51.91868541619013, 
  longitude: 4.48439474997006, 
  desc:"Wijnhaven 99",
  color: "black",
  adress: "Wijnhaven 99"
  
}
];
const List = () => (


  
  <Card>
    <Card.Title title="Museumpark" subtitle="Yasarstraat 3409 AB" left={LeftContent} />
    <Card.Content>
     
    </Card.Content>
 
    <Card.Actions>
      <Button>Edit</Button>
      <Button>Delete</Button>
        <Button>Go to location</Button>
    </Card.Actions>


       <Card.Title title="Museumpark" subtitle="Yasarstraat 3409 AB" left={LeftContent} />
    <Card.Content>
     
    </Card.Content>
 
    <Card.Actions>
      <Button>Edit</Button>
      <Button>Delete</Button>
        <Button>Go to location</Button>
    </Card.Actions>
  </Card>

  
);

export default List;