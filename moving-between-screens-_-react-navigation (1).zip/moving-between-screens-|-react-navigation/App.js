import * as React from 'react';
import { Button, View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import MapScreen from "./MapScreen";
import Marker from "./MapMarker";
import List from "./List";

function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1, marginTop:50 }}>
      <Button

       color="#841584"
       style={{marginTop:50,   paddingVertical: 30,}}
        title="Settings"
        onPress={() => navigation.navigate('Marker', {desc: "Museumpark", lat: 51.83346582941059, long: 4.319666352004428 })}
      />
      <Button
        title="See all loactions on Map"
        onPress={() => navigation.navigate('Details')}
      />

         <Button
        title="Listp"
        onPress={() => navigation.navigate('List')}
      />

     
    </View>
  );
}

function DetailsScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Details Screen</Text>
    </View>
  );
}

const Stack = createNativeStackNavigator();

function App() {
  const [title, settitle]=React.useState("null")
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} 
         options={{
          title: 'Hogeschool Rotterdam Locations',
          headerStyle: {
            backgroundColor: '#f4511e',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
        
        />
        <Stack.Screen name="Details" component={MapScreen}
        
          options={{
          title: 'All Locations on Map',
          headerStyle: {
            backgroundColor: 'purple',
          },
          headerTintColor: 'yellow',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
        
         />
          <Stack.Screen name="Marker" component={Marker} />
           <Stack.Screen name="List" component={List} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
