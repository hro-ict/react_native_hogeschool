import React from 'react';
import { View, Button } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import openMap from 'react-native-open-maps';

const App = () => {
  const openLocationInMaps = () => {
    const latitude = 37.7749; // Vervang dit met de gewenste breedtegraad
    const longitude = -122.4194; // Vervang dit met de gewenste lengtegraad

    openMap({ latitude, longitude });
  };

  return (
    <View style={{ flex: 1 }}>
      <MapView
        style={{ flex: 1 }}
        initialRegion={{
          latitude: 37.78825,
          longitude: -122.4324,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        <Marker
          coordinate={{ latitude: 37.78825, longitude: -122.4324 }}
          title="Marker 1"
          description="This is marker 1"
        />
        <Marker
          coordinate={{ latitude: 37.7749, longitude: -122.4194 }}
          title="Marker 2"
          description="This is marker 2"
        />
      </MapView>

      <Button title="" onPress={openLocationInMaps} />
    </View>
  );
};

export default App;
